# GitHub 雷达 · dsh-plugin-github-radar

> 在 DSH 里刷 GitHub 趋势：看今天什么在涨，收藏、读 README（一键中文）、把仓库拉下来。

![DSH](https://img.shields.io/badge/DSH-%E2%89%A5%200.2.1--rc.5-4f46e5?style=flat-square)
![Node](https://img.shields.io/badge/node-%E2%89%A5%2020-339933?style=flat-square&logo=nodedotjs&logoColor=white)
![License](https://img.shields.io/badge/license-MIT-2ea44f?style=flat-square)

![GitHub 雷达面板](docs-panel.png)

装好后左栏多一个「GitHub 雷达」入口，点开就是趋势榜。它不是独立网页，是 DSH 自己的面板，亮色 / 暗色主题跟着 DSH 走。

## 安装

```sh
dsh plugin --profile <profile> add https://github.com/1578361862-art/dsh-plugin-github-radar/releases/latest/download/dsh-plugin-github-radar.tgz
```

`<profile>` 换成你实际的 profile 名：DSH Desktop 是 `desktop`，`dsh web` 一般是 `web`。装完重启 DSH。

也可以从仓库源码装（本插件没有构建步骤）：

```sh
dsh plugin --profile <profile> add github:1578361862-art/dsh-plugin-github-radar
```

卸载：

```sh
dsh plugin --profile <profile> remove dsh-plugin-github-radar
```

收藏和缓存留在 `~/Data/github-radar`，不想要就一起删。

## 能做什么

- **刷榜**：今日 / 本周 / 本月，17 种语言，按仓库名和描述过滤
- **收藏**：觉得有用先收着，存在本地 `collection.json`，不依赖账号、不需要登录
- **读 README**：点开就在面板里渲染，不用跳页面
- **一键中文**：正文翻成中文，代码块保持原样
- **克隆**：浅克隆到 `~/Code`，拉下来就能开工

## 一次典型用法

1. 打开面板，选「今日」和 TypeScript
2. 点某个仓库看 README，拿不准就切「中文」
3. 值得留：点收藏（本地记账，记下名字、描述、语言、星数、收录时间）；值得试：点克隆

## README 中文

弹层右上角「原文 / 中文」：

- 只翻正文，代码块原样保留
- 长 README 分批翻，点「继续翻译」接着来
- 翻过的部分存在本地，下次打开直接看
- 翻得不好可以「重新翻译」

翻译引擎在弹层左下角选：

| 引擎 | 说明 |
| --- | --- |
| DSH 已配置的模型 | 默认，不额外要 key |
| Google 翻译 | 质量稳，需要 Cloud Translation API key，按字符计费 |
| MyMemory | 免费机翻，限额很死，翻两篇就可能触发限流 |

### 配 Google 翻译

1. GCP 控制台启用 **Cloud Translation API**
2. 创建 API key，建议限制为只允许 Translation API
3. 面板里切到「Google 翻译」，粘 key 保存

每月 50 万字符免费，超出约 $20 / 百万字符。你手上没有 GCP 额度的话，用 DSH 模型更划算。

## 登录 GitHub

登录只为了**克隆私有仓库**和抬高接口额度（60 → 5000 次/小时）。刷榜、读 README、收藏、克隆公开仓库都不需要登录，收藏本身就是纯本地的。

右上角「登录 GitHub」，两种方式：

1. 粘贴 Personal Access Token（classic 要 `repo` 范围，fine-grained 要有仓库读权限）
2. 留空，终端里先跑 `gh auth login`，插件会自动复用

token 只存在本机 `~/Data/github-radar/auth.json`（权限 600），不会写进仓库或 `.git/config`。

## 数据在哪

```text
~/Data/github-radar/        # 收藏、登录、设置、译文缓存
~/Code/<owner>__<repo>/     # 克隆下来的仓库
```

克隆目录带 `owner__` 前缀，避免和 `~/Code` 下已有的同名目录撞车。两个位置都能用 `GITHUB_RADAR_HOME` / `GITHUB_RADAR_CODE` 改。

## 常见问题

**榜单空的，显示「这次没扫到」？**
GitHub 的 trending 页面解析失败或限流。未登录只有 15 条；等一会儿重试，或看看是不是 GitHub 改版了。

**装完看不到面板？**
重启 DSH。

**翻译只翻了一半？**
长 README 分批，点「继续翻译」。

**提示没有挂载模型？**
当前 profile 没配模型，或者改用 Google / MyMemory。

**私有仓库克隆失败？**
先登录，确认 token 对那个仓库有读权限。

## 已知限制

- 未登录时榜单只有 15 条
- GitHub 一改版，抓取就可能失灵（当天缓存还能看）
- 克隆是 `--depth 1`，要完整历史进目录 `git fetch --unshallow`
- README 用轻量渲染器，`<details>` 之类会被摊平

## 想改代码

宿主 / 客户端分工、接口列表、缓存与翻译实现见 [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)；发布与分发见 [docs/PUBLISHING.md](docs/PUBLISHING.md)。

## 许可

[MIT](LICENSE) © Yee
